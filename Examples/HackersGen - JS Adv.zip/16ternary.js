const isMember = true;
const price = isMember ? '$2.00' : '$10.00';

console.log(price);
