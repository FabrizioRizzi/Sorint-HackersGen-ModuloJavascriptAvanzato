# HackersGen

Just open index.html in your browser and open the developer console (F12).

To change the javascript file loaded, change the src attribute of the script tag at the end of the body, inside the index.html.

Good luck with it ;-)